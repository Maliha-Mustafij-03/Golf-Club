<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
 
     ?>

   
    <title>Golf Club Management System | Home Page</title>
    <?php include_once('includes/header.php');?>

    <!doctype html>
<html lang="en">
  <head>

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <!-- <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&family=Sono:wght@200;300;400;500;700&display=swap" rel="stylesheet"> -->
                        
        <link rel="stylesheet" href="css/bootstrap.min.css">

        <link rel="stylesheet" href="css/bootstrap-icons.css">

        <link rel="stylesheet" href="css/owl.carousel.min.css">
        
        <link rel="stylesheet" href="css/owl.theme.default.min.css">

        <link href="css/templatemo-pod-talk.css" rel="stylesheet">
        
  </head>
  <body id="home">



<script src="assets/js/jquery-3.3.1.min.js"></script> <!-- Common jquery plugin -->
<!--bootstrap working-->
<script src="assets/js/bootstrap.min.js"></script>
<!-- //bootstrap working-->
<!-- disable body scroll which navbar is in active -->
<script>
$(function () {
  $('.navbar-toggler').click(function () {
    $('body').toggleClass('noscroll');
  })
});
</script>
<!-- disable body scroll which navbar is in active -->

<div class="w3l-hero-headers-9">
  <div class="css-slider">
    <input id="slide-1" type="radio" name="slides" checked>
    <section class="slide slide-one">
      <div class="container">
        <div class="banner-text">
          <h4>It is Modern</h4>
          <h3>It is Creative<br>
            It is Lifestyle</h3>

            <a href="enroll-application.php" class="btn logo-button top-margin">Get An Enrollment</a>
        </div>
      </div>
      
    </section>
    <input id="slide-2" type="radio" name="slides">
    <section class="slide slide-two">
      <div class="container">
        <div class="banner-text">
          <h4>It is Modern</h4>
          <h3>It is Creative<br>
            It is lifestyle</h3>
          <a href="enroll-application.php" class="btn logo-button top-margin">Get An Enrollment</a>
        </div>
      </div>
      <!-- <nav>
        <label for="slide-1" class="next">&#10093;</label>
        <label for="slide-2" class="prev">&#10094;</label>
       
      </nav> -->
    </section>
    <header>
      <label for="slide-1" id="slide-1"></label>
      <label for="slide-2" id="slide-2"></label>
     
    </header>
  </div>
</div> 
<section class="w3l-call-to-action_9">
    <div class="call-w3 ">
        <div class="container">
            <div class="grids">
                    <div class="grids-content row">

                        <div class="column col-lg-4 col-md-6 color-2 ">
                            <div>
                            <h4 class=" ">Golf club is Most Popular</h4>
                            <p class="para ">Courses</p>
                            <a href="about.php" class="action-button btn mt-md-4 mt-3">Read more</a>
                        </div>
                    </div>
                        <div class="column col-lg-4 col-md-6 col-sm-6 back-image  ">
                            <img src="assets/images/55.jpg" alt="product" class="img-responsive ">
                        </div>
                        <div class="column col-lg-4 col-md-6 col-sm-6 back-image2 ">
                            <img src="assets/images/66.jpg" alt="product" class="img-responsive ">
                          </div>
                          
                    </div>
                </div>
        </div>
    </div>

  
        

        

    

         
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12">
                            <div class="text-center mb-5 pb-2">
                                <h1 class="text-black"> Honarable Golf Members</h1>

                                

                                
                            </div>

                            <div class="owl-carousel owl-theme">
                                <div class="owl-carousel-info-wrap item">
                                    <img src="images/profile/image1.jpg" class="owl-carousel-image img-fluid" alt="">

                                    <div class="owl-carousel-info">
                                        <h4 class="mb-2">
                                            demo name
                                            <img src="images/verified.png" class="owl-carousel-verified-image img-fluid" alt="">
                                        </h4>

                                        <span class="badge">demo data</span>

                                        <span class="badge">demo data</span>
                                    </div>

                                    
                                </div>

                                <div class="owl-carousel-info-wrap item">
                                    <img src="images/profile/image2.jpg" class="owl-carousel-image img-fluid" alt="">

                                    <div class="owl-carousel-info">
                                        <h4 class="mb-2">
                                            demo name
                                            <img src="images/verified.png" class="owl-carousel-verified-image img-fluid" alt="">
                                        </h4>

                                        <span class="badge">Creative</span>

                                        <span class="badge">Design</span>
                                    </div>

                                    
                                </div>

                                <div class="owl-carousel-info-wrap item">
                                    <img src="images/profile/image6.jpg" class="owl-carousel-image img-fluid" alt="">

                                    <div class="owl-carousel-info">
                                        <h4 class="mb-2">demo name</h4>

                                        <span class="badge">Modeling</span>

                                        <span class="badge">Fashion</span>
                                    </div>

                                    
                                </div>

                                <div class="owl-carousel-info-wrap item">
                                    <img src="images/profile/image5.jpg" class="owl-carousel-image img-fluid" alt="">

                                    <div class="owl-carousel-info">
                                        <h4 class="mb-2">demo name</h4>

                                        <span class="badge">Acting</span>
                                    </div>

                                    
                                </div>

                                <div class="owl-carousel-info-wrap item">
                                    <img src="images/profile/image3.jpg" class="owl-carousel-image img-fluid" alt="">

                                    <div class="owl-carousel-info">
                                        <h4 class="mb-2">
                                            demo name
                                            <img src="images/verified.png" class="owl-carousel-verified-image img-fluid" alt="">
                                        </h4>

                                        <span class="badge">Influencer</span>
                                    </div>

                                    
                                </div>

                                <div class="owl-carousel-info-wrap item">
                                    <img src="images/profile/image4.jpg" class="owl-carousel-image img-fluid" alt="">

                                    <div class="owl-carousel-info">
                                        <h4 class="mb-2">demo name</h4>

                                        <span class="badge">Education</span>
                                    </div>

                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>


            
        

   

</section>
<section class="w3l-teams-15">
	<div class="team-single-main ">
		<div class="container">
		
				<div class="column2 image-text">
					<h3 class="team-head ">Army Golf Club has been established for over 140 years and offers a warm and friendly welcome to all visitors and members alike.</h3>
					<p class="para  text ">
						
We are recognised as one of the top courses within Hampshire offering a mature and challenging test on one of the South East's finest Woodland/Heathland courses. Membership is available in all categories. We welcome the beginner and the seasoned golfer and are determined to make the experience of joining Army Golf Club a pleasure.

Our Corporate and Society packages are very popular, offering tremendous value for money to all golfers who would like to visit us for an informal round.</p>
						<a href="enroll-application.php" class="btn logo-button top-margin mt-4">Get Enroll in Courses </a>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="w3l-specification-6">
    <div class="specification-layout ">
        <div class="container">
            <div class=" row">
                <div class="col-lg-6 back-image">
                    <img src="assets/images/777.jpg" alt="product" class="img-responsive ">
                </div>
                <div class="col-lg-6 about-right-faq align-self">
                    <h3 class="title-big"><a href="about.html"> Recommended </a></h3>
                    <p class="mt-3 para"> Army Golf Club (AGC) is a short but very attractive course for Golfers in Bangladesh. It is being run under the supervision of Club President.</p>
                        <div class="hair-cut">
                            <div >
                    <ul class="w3l-right-book">
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                        <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                    </ul>
                </div>
                    <div  class="image-right">
                        <ul class="w3l-right-book">
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                            <li><span class="fa fa-check" aria-hidden="true"></span><a href="about.html">demo</a></li>
                        </ul>
                </div>
            </div>
        </div>
</section>
<?php include_once('includes/footer.php');?>
<!-- move top -->
<button onclick="topFunction()" id="movetop" title="Go to top">
	<span class="fa fa-long-arrow-up"></span>
</button>
<script>
	// When the user scrolls down 20px from the top of the document, show the button
	window.onscroll = function () {
		scrollFunction()
	};

	function scrollFunction() {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
			document.getElementById("movetop").style.display = "block";
		} else {
			document.getElementById("movetop").style.display = "none";
		}
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	}
</script>
<!-- /move top -->
</body>
<!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/custom.js"></script>
</html>