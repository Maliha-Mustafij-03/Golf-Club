  <div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
          <ul class="nav" id="side-menu">
            <li>
              <a href="dashboard.php"><i class="fa fa-home nav_icon"></i>Dashboard</a>
            </li>
            <li>
              <a href="add-courses.php"><i class="fa fa-cogs nav_icon"></i>Courses<span class="fa arrow"></span> </a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="add-courses.php">Add courses/packages</a>
                </li>
                <li>
                  <a href="manage-courses.php">Manage courses/packages</a>
                </li>
              </ul>
              <!-- /nav-second-level -->
            </li>
            <li class="">
              <a href="about-us.php"><i class="fa fa-book nav_icon"></i>Pages <span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="about-us.php">About Us</a>
                </li>
                <li>
                  <a href="contact-us.php">Contact Us</a>
                </li>
              </ul>
              <!-- /nav-second-level -->
            </li>
          
            <li>
              <a href="all-application.php"><i class="fa fa-check-square-o nav_icon"></i>Apply data<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="all-application.php">All Applicant/Member</a>
                </li>
                <li>
                  <a href="new-application.php">New Applicant/Member</a>
                </li>
                <li>
                  <a href="accepted-application.php">Accepted Request</a>
                </li>
                <li>
                  <a href="rejected-application.php">Rejected Request</a>
                </li>
              </ul>
              <!-- //nav-second-level -->
            </li>
           
        
           <li>
              <a href="readenq.php"><i class="fa fa-check-square-o nav_icon"></i>Enquiry<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li><a href="readenq.php">Read Enquiry</a></li>
        <li><a href="unreadenq.php">Unread Enquiry</a></li>
               
              </ul>
              <!-- //nav-second-level -->
            </li>
             <li>
              <a href="member-list.php" class="chart-nav"><i class="fa fa-users nav_icon"></i>Member List</a>
            </li>
              <li>
              <a href="#"><i class="fa fa-check-square-o nav_icon"></i>Reports<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                 <li><a href="bwdates-reports-ds.php"> B/w dates</a></li>
                   
                    <li><a href="course-reports.php">Course taken Reports</a></li>
              </ul>
              <!-- //nav-second-level -->
            </li>

    <li>
              <a href="invoices.php" class="chart-nav"><i class="fa fa-file-text-o nav_icon"></i>Invoices</a>
            </li>
            <li>
              <a href="search-application.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Search for a Course/Membership Apply</a>
            </li>
            <li>
              <a href="search-invoices.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Search Invoice</a>
            </li>
          

          </ul>
          <div class="clearfix"> </div>
          <!-- //sidebar-collapse -->
        </nav>
      </div>
    </div>