<!--footer-->
    <div class="footer">
       <p>&copy; 2023 Admin Panel.</p>
    </div>
        <!--//footer-->