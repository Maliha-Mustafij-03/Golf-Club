How to run the Golf Club Website Project



1.Paste inside root directory(for xampp xampp/htdocs)

2.Open PHPMyAdmin (http://localhost/phpmyadmin)

3.Create a database with name bpmsdb

4.Import bpmsdb.sql file(given inside the SQL file folder)

5.Run the script http://localhost/bpmsdb

Admin Credential
Username: admin
Password: 1234

Login Credential
User e-mail:maliha1218@gmail.com
Password: 1234

